function Footer(){
    return(
        <p className="footer fixed-bottom">
            PLEASE USE CHROME WHEN EVALUATING <br />
            No house plants were harmed in the making of this web app.<br/>
            &copy; Brenna Wilson & Brianna Kromrey (CS340 - Group 29)
        </p>
    );
}

export default Footer;